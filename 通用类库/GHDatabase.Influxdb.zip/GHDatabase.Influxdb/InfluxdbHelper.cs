﻿using InfluxData.Net.Common.Enums;
using InfluxData.Net.InfluxDb;
using InfluxData.Net.InfluxDb.Models;
using InfluxData.Net.InfluxDb.Models.Responses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GHDatabase.Influxdb
{
   public class InfluxdbHelper
    {
        private static readonly  InfluxDbClient _client;
        private  static  object obj=new object();
        public InfluxdbHelper()
        {
           
        }

         static InfluxdbHelper()
        {
            lock (obj)
            {
                if (_client == null)
                {
                    _client = new InfluxDbClient(ConfigurationManager.AppSettings["influxdb_ip"], "", "",
                        InfluxDbVersion.Latest);
                }
            }

            CheckDB();

        }
        private static async Task CheckDB()
        {
            var dbname = ConfigurationManager.AppSettings["influxdb_db"];
            if(!string.IsNullOrEmpty(dbname))
            {
                dbname = "ghy_history";
            }

            if (_client != null)
            {
                var db = await _client.Database.GetDatabasesAsync();
                if (db.Where(d => d.Name == dbname).Count() == 0)
                {
                    await _client.Database.CreateDatabaseAsync(dbname);
                }
            }

        }

        public static InfluxdbHelper Instance { get; } = new InfluxdbHelper();

        public async Task Write(Point point,string dbname)
        {
            await _client.Client.WriteAsync(point, dbname);
        }

        public async Task Write(IEnumerable<Point> points, string dbname)
        {
            await _client.Client.WriteAsync(points, dbname);
        }
      
        public async Task<List<object>> Query(string sql, string dbname)
        {
             var db= await _client.Client.QueryAsync(sql, dbname);
             List<object> list = new List<object>();
             if (db != null && db.Count()>0)
             {
                 foreach (var series in db)
                 {
                     list.AddRange(series.Values.AsEnumerable().Select(d=>new{time=d[0],value=d[1]}).ToList());
                 }
             }
             return list;
        }
        /// <summary>
        /// 多变量查询
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="dbname"></param>
        /// <returns></returns>
        public async Task<List<object>> Querys(string sql, string dbname)
        {
            var db = await _client.Client.QueryAsync(sql, dbname);
            List<object> list = new List<object>();
            if (db != null && db.Count() > 0)
            {
                foreach (var series in db)
                {
                    list.Add(series.Values.AsEnumerable().Select(d => new { time = d[0], value = d[1] }).ToList());
                }
            }
            return list;
        }
        /// <summary>
        /// 多变量 多语句
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="dbname"></param>
        /// <returns></returns>
        public async Task<List<object>> Querys(string[] sql, string dbname)
        {
            var db = await _client.Client.MultiQueryAsync(sql, dbname);
            List<object> list = new List<object>();
            foreach (var d in db)
            {
                if (d != null && d.Count() > 0)
                {
                    foreach (var series in d)
                    {
                        list.Add(series.Values.AsEnumerable().Select(data => new { time = data[0], value = data[1] }).ToList());
                    }
                }
            }
            return list;
        }

        public async Task<List<object>> Query(string[] sql, string dbname)
        {
            var db = await _client.Client.MultiQueryAsync(sql, dbname);
            List<object> list = new List<object>();
            foreach (var d in db)
            {
                if (d != null && d.Count() > 0)
                {
                    foreach (var series in d)
                    {
                        list.AddRange(series.Values.AsEnumerable().Select(data => new { time = data[0], value = data[1] }).ToList());
                    }
                }
            }
            return list;
        }

        public async Task Query(string sql, params object[] param)
        {
            throw new NotImplementedException();
        }

        public async Task GetMeasureMents(string dbname)
        {
            await _client.Serie.GetMeasurementsAsync(dbname);
        }
    }
}
